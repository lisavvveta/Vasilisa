document.addEventListener("DOMContentLoaded", function(event) {
    console.log("DOM fully loaded and parsed");
  });
document.readyState(function() {
        $('#basket > p'). toggle (
        function() {
            $('#basket > div'). show ();
            },
        function() {
            $('#basket > div').hide ();
        }
)
}
                  );